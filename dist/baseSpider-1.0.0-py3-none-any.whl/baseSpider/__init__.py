
from .baseSpider import BaseSpiderObject
from .items import BaseItem,RequestItem
from .pipelines import baseSpiderPipeline